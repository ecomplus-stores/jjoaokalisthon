# Widget Search

Storefront plugin with Vue component for instant search engine on E-Com Plus stores
